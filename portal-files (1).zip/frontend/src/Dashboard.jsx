import { useEffect, useState } from 'react'
import { supabase } from './portal/supabase.js'
import { useAlerts } from './portal/useAlerts.js'
import { capacity } from './portal/helpers.js'
import Login from './portal/Login.jsx'
import ResourcesPanel from './portal/ResourcesPanel.jsx'
import AlertsPanel from './portal/AlertsPanel.jsx'
import './portal/portal.css'

export default function Dashboard() {
  const [session, setSession] = useState(null)
  const [checking, setChecking] = useState(true)
  const [hospital, setHospital] = useState(null)
  const [error, setError] = useState('')
  const [soundOn, setSoundOn] = useState(true)

  // 1. Know whether someone is logged in
  useEffect(() => {
    if (!supabase) {
      setChecking(false)
      return
    }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setChecking(false)
    })
    const { data } = supabase.auth.onAuthStateChange((_event, s) => setSession(s))
    return () => data.subscription.unsubscribe()
  }, [])

  const userId = session ? session.user.id : null

  // 2. Find which hospital this user belongs to
  useEffect(() => {
    setHospital(null)
    setError('')
    if (!userId) return
    async function loadHospital() {
      const { data: staff, error: e1 } = await supabase
        .from('hospital_staff')
        .select('hospital_id')
        .eq('user_id', userId)
        .maybeSingle()
      if (e1) { setError(e1.message); return }
      if (!staff) {
        setError('This account is not linked to a hospital yet. Run the SQL step again after creating the user.')
        return
      }
      const { data: h, error: e2 } = await supabase
        .from('hospitals')
        .select('*')
        .eq('id', staff.hospital_id)
        .single()
      if (e2) { setError(e2.message); return }
      setHospital(h)
    }
    loadHospital()
  }, [userId])

  // 3. Live alerts for this hospital
  const { alerts, error: alertError, live, reload } = useAlerts(hospital ? hospital.id : null, soundOn)
  const pending = alerts.filter((a) => a.status === 'sent').length

  useEffect(() => {
    document.title = pending > 0 ? '(' + pending + ') NEW ALERT - CareRadar' : 'CareRadar - Hospital Portal'
  }, [pending])

  if (!supabase) {
    return (
      <div className="wrap">
        <div className="card">
          <h2>Setup needed</h2>
          <p>VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY is missing. Add them to frontend/.env, then stop and restart npm run dev.</p>
        </div>
      </div>
    )
  }

  if (checking) return <div className="wrap"><p>Loading...</p></div>
  if (!session) return <Login />

  const cap = hospital ? capacity(hospital.beds_free, hospital.icu_free) : null

  return (
    <div>
      <div className="header">
        <div className="header-inner">
          <div>
            <h1>{hospital ? hospital.name : 'CareRadar Hospital Portal'}</h1>
            <div className="sub">Hospital Portal - {session.user.email}</div>
          </div>
          <div className="header-actions">
            <span className="live"><span className={live ? 'dot on' : 'dot'}></span>{live ? 'Live' : 'Connecting...'}</span>
            <button onClick={() => setSoundOn(!soundOn)}>{soundOn ? 'Sound on' : 'Sound off'}</button>
            <button onClick={() => supabase.auth.signOut()}>Sign out</button>
          </div>
        </div>
      </div>

      <div className="wrap">
        {error && <div className="card"><p className="error">{error}</p></div>}
        {hospital && (
          <>
            <div className="kpis">
              <div className={'kpi ' + cap.cls}><span>Status</span><strong>{cap.label}</strong></div>
              <div className="kpi"><span>Beds free</span><strong>{hospital.beds_free || 0}</strong></div>
              <div className="kpi"><span>ICU free</span><strong>{hospital.icu_free || 0}</strong></div>
              <div className="kpi"><span>Ventilators</span><strong>{hospital.ventilators_free || 0}</strong></div>
              <div className={pending > 0 ? 'kpi hot' : 'kpi'}><span>New alerts</span><strong>{pending}</strong></div>
            </div>
            <div className="grid">
              <ResourcesPanel key={hospital.id} hospital={hospital} onSaved={setHospital} />
              <AlertsPanel hospitalId={hospital.id} alerts={alerts} error={alertError} onChange={reload} />
            </div>
          </>
        )}
      </div>
    </div>
  )
}
