import { useEffect, useRef, useState } from 'react'
import { supabase } from './supabase.js'
import { beep } from './helpers.js'

export function useAlerts(hospitalId, soundOn) {
  const [alerts, setAlerts] = useState([])
  const [error, setError] = useState('')
  const [live, setLive] = useState(false)
  const seen = useRef(null)
  const soundRef = useRef(soundOn)
  soundRef.current = soundOn

  async function load() {
    if (!hospitalId) return
    const { data, error } = await supabase
      .from('alerts')
      .select('*')
      .eq('hospital_id', hospitalId)
      .order('created_at', { ascending: false })
      .limit(100)
    if (error) {
      setError(error.message)
      return
    }
    setError('')
    setAlerts(data)
    if (seen.current === null) {
      seen.current = new Set(data.map((a) => a.id))
    } else {
      const fresh = data.filter((a) => !seen.current.has(a.id) && a.status === 'sent')
      data.forEach((a) => seen.current.add(a.id))
      if (fresh.length > 0 && soundRef.current) beep()
    }
  }

  useEffect(() => {
    if (!hospitalId) return
    seen.current = null
    setAlerts([])
    load()
    const channel = supabase
      .channel('alerts-' + hospitalId)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'alerts', filter: 'hospital_id=eq.' + hospitalId },
        () => load()
      )
      .subscribe((status) => setLive(status === 'SUBSCRIBED'))
    // backup refresh in case the live connection drops
    const timer = setInterval(load, 15000)
    return () => {
      clearInterval(timer)
      supabase.removeChannel(channel)
    }
  }, [hospitalId])

  return { alerts, error, live, reload: load }
}
