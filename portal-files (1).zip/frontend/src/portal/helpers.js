export const BLOOD = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']

export const SPECIALTIES = [
  'Cardiology', 'Neurology', 'Trauma', 'Pediatrics', 'Obstetrics',
  'Burns', 'Orthopedics', 'Nephrology', 'Oncology',
]

export const ACTIVE = ['sent', 'acknowledged', 'ready']

const CRITICAL = ['cardiac', 'heart', 'stroke', 'trauma', 'accident', 'burn', 'bleed']

export function isCritical(type) {
  const t = (type || '').toLowerCase()
  return CRITICAL.some((word) => t.includes(word))
}

export function timeAgo(iso) {
  if (!iso) return 'never'
  const mins = Math.floor((Date.now() - new Date(iso).getTime()) / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return mins + ' min ago'
  const hours = Math.floor(mins / 60)
  if (hours < 24) return hours + ' h ago'
  return Math.floor(hours / 24) + ' d ago'
}

export function capacity(beds, icu) {
  const b = beds || 0
  const i = icu || 0
  if (b === 0 && i === 0) return { label: 'FULL', cls: 'red' }
  if (i <= 1 || b <= 3) return { label: 'LIMITED', cls: 'amber' }
  return { label: 'AVAILABLE', cls: 'green' }
}

export function arrival(alert, nowMs) {
  if (alert.eta_min == null) return ''
  const arriveAt = new Date(alert.created_at).getTime() + alert.eta_min * 60000
  const mins = Math.round((arriveAt - nowMs) / 60000)
  if (mins > 0) return 'Arriving in ' + mins + ' min'
  if (mins > -3) return 'Arriving now'
  return 'Overdue by ' + Math.abs(mins) + ' min'
}

export function beep() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext
    const ctx = new Ctx()
    ;[0, 0.28, 0.56].forEach((delay) => {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.frequency.value = 880
      gain.gain.value = 0.15
      osc.start(ctx.currentTime + delay)
      osc.stop(ctx.currentTime + delay + 0.18)
    })
  } catch (e) {
    // sound is optional, ignore errors
  }
}
