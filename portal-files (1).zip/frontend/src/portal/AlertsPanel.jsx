import { useEffect, useState } from 'react'
import { supabase } from './supabase.js'
import { ACTIVE, arrival, isCritical } from './helpers.js'

const NEXT = {
  sent: [['acknowledged', 'Acknowledge'], ['declined', 'Decline']],
  acknowledged: [['ready', 'Ready for patient'], ['declined', 'Decline']],
  ready: [['arrived', 'Patient arrived']],
}

const DEMO = [
  ['Cardiac arrest', 'Chest pain, 58 year old male, unconscious'],
  ['Road accident', 'Two-wheeler collision, head injury, bleeding'],
  ['Stroke', 'Sudden weakness on left side, slurred speech'],
  ['Burns', 'Kitchen fire, 30 percent burns, adult female'],
  ['Pregnancy emergency', 'Labour complications, 34 weeks'],
]

export default function AlertsPanel({ hospitalId, alerts, error, onChange }) {
  const [tab, setTab] = useState('active')
  const [now, setNow] = useState(Date.now())
  const [localError, setLocalError] = useState('')

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 30000)
    return () => clearInterval(timer)
  }, [])

  const startOfDay = new Date()
  startOfDay.setHours(0, 0, 0, 0)
  const today = alerts.filter((a) => new Date(a.created_at) >= startOfDay)
  const etas = today.filter((a) => a.eta_min != null).map((a) => a.eta_min)
  const avgEta = etas.length ? Math.round(etas.reduce((x, y) => x + y, 0) / etas.length) : null

  const list = alerts.filter((a) => (tab === 'active' ? ACTIVE.includes(a.status) : !ACTIVE.includes(a.status)))
  const activeCount = alerts.filter((a) => ACTIVE.includes(a.status)).length

  async function setStatus(id, status) {
    setLocalError('')
    const { error } = await supabase.from('alerts').update({ status: status }).eq('id', id)
    if (error) setLocalError(error.message)
    await onChange()
  }

  async function sendDemo() {
    setLocalError('')
    const pick = DEMO[Math.floor(Math.random() * DEMO.length)]
    const { error } = await supabase.from('alerts').insert({
      hospital_id: hospitalId,
      emergency_type: pick[0],
      eta_min: 4 + Math.floor(Math.random() * 12),
      summary: pick[1],
    })
    if (error) setLocalError('Demo alert failed: ' + error.message + ' (run the SQL step first)')
    await onChange()
  }

  const shownError = localError || error

  return (
    <div className="card">
      <div className="card-head">
        <h2>Incoming alerts</h2>
        <button type="button" onClick={sendDemo}>Send demo alert</button>
      </div>

      <div className="mini-stats">
        <div><strong>{today.length}</strong><span>alerts today</span></div>
        <div><strong>{activeCount}</strong><span>active now</span></div>
        <div><strong>{avgEta == null ? '-' : avgEta + ' min'}</strong><span>average ETA</span></div>
      </div>

      <div className="tabs">
        <button className={tab === 'active' ? 'tab on' : 'tab'} onClick={() => setTab('active')}>Active</button>
        <button className={tab === 'history' ? 'tab on' : 'tab'} onClick={() => setTab('history')}>History</button>
      </div>

      {shownError && <p className="error">{shownError}</p>}
      {list.length === 0 && !shownError && (
        <p className="muted empty">
          {tab === 'active' ? 'No active alerts. New ones appear here instantly.' : 'No past alerts yet.'}
        </p>
      )}

      {list.map((a) => (
        <div key={a.id} className={'alert ' + (isCritical(a.emergency_type) ? 'critical' : 'normal') + (a.status === 'sent' ? ' new' : '')}>
          <div className="alert-head">
            <strong>{a.emergency_type || 'Emergency'}</strong>
            <span className={'badge ' + a.status}>{a.status === 'sent' ? 'NEW' : a.status}</span>
          </div>
          <div className="eta">
            {tab === 'active' ? arrival(a, now) : new Date(a.created_at).toLocaleString()}
          </div>
          {a.summary && <p className="summary">{a.summary}</p>}
          {tab === 'active' && (
            <div className="alert-actions">
              {(NEXT[a.status] || []).map((b) => (
                <button key={b[0]} className={b[0] === 'declined' ? '' : 'primary'} onClick={() => setStatus(a.id, b[0])}>
                  {b[1]}
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
