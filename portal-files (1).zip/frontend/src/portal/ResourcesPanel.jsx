import { useState } from 'react'
import { supabase } from './supabase.js'
import { BLOOD, SPECIALTIES, timeAgo } from './helpers.js'

function Counter({ label, value, onChange }) {
  return (
    <div className="counter">
      <div className="counter-label">{label}</div>
      <div className="counter-row">
        <button type="button" onClick={() => onChange(Math.max(0, value - 1))}>-</button>
        <input
          type="number"
          min="0"
          value={value}
          onChange={(e) => onChange(Math.max(0, parseInt(e.target.value, 10) || 0))}
        />
        <button type="button" onClick={() => onChange(value + 1)}>+</button>
      </div>
    </div>
  )
}

function same(a, b) {
  return JSON.stringify([...(a || [])].sort()) === JSON.stringify([...(b || [])].sort())
}

function Chips({ options, selected, onToggle }) {
  return (
    <div className="chips">
      {options.map((o) => (
        <button
          type="button"
          key={o}
          className={selected.includes(o) ? 'chip on' : 'chip'}
          onClick={() => onToggle(o)}
        >
          {o}
        </button>
      ))}
    </div>
  )
}

export default function ResourcesPanel({ hospital, onSaved }) {
  const [beds, setBeds] = useState(hospital.beds_free || 0)
  const [icu, setIcu] = useState(hospital.icu_free || 0)
  const [vents, setVents] = useState(hospital.ventilators_free || 0)
  const [oxygen, setOxygen] = useState(!!hospital.oxygen)
  const [ct, setCt] = useState(!!hospital.has_ct)
  const [trauma, setTrauma] = useState(!!hospital.has_trauma)
  const [blood, setBlood] = useState(hospital.blood_groups || [])
  const [specs, setSpecs] = useState(hospital.specialties || [])
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')
  const [isError, setIsError] = useState(false)

  const bloodOptions = [...BLOOD, ...(hospital.blood_groups || []).filter((x) => !BLOOD.includes(x))]
  const specOptions = [...SPECIALTIES, ...(hospital.specialties || []).filter((x) => !SPECIALTIES.includes(x))]

  const dirty =
    beds !== (hospital.beds_free || 0) ||
    icu !== (hospital.icu_free || 0) ||
    vents !== (hospital.ventilators_free || 0) ||
    oxygen !== !!hospital.oxygen ||
    ct !== !!hospital.has_ct ||
    trauma !== !!hospital.has_trauma ||
    !same(blood, hospital.blood_groups) ||
    !same(specs, hospital.specialties)

  const ageMin = hospital.updated_at ? (Date.now() - new Date(hospital.updated_at).getTime()) / 60000 : 0
  const stale = ageMin > 120

  function toggle(list, setList, value) {
    setList(list.includes(value) ? list.filter((x) => x !== value) : [...list, value])
  }

  async function save() {
    setSaving(true)
    setMsg('')
    setIsError(false)
    const { data, error } = await supabase
      .from('hospitals')
      .update({
        beds_free: beds,
        icu_free: icu,
        ventilators_free: vents,
        oxygen: oxygen,
        has_ct: ct,
        has_trauma: trauma,
        blood_groups: blood,
        specialties: specs,
      })
      .eq('id', hospital.id)
      .select()
      .single()
    if (error) {
      setIsError(true)
      setMsg('Could not save: ' + error.message)
    } else {
      onSaved(data)
      setMsg('Saved. Patients now see the new numbers.')
    }
    setSaving(false)
  }

  return (
    <div className="card">
      <div className="card-head">
        <h2>Live resources</h2>
        <span className="muted">Last updated {timeAgo(hospital.updated_at)}</span>
      </div>

      {stale && (
        <div className="stale">
          <span>Your numbers are over 2 hours old. Patients may not trust them.</span>
          <button className="primary" onClick={save} disabled={saving}>Numbers are still correct</button>
        </div>
      )}

      <div className="counters">
        <Counter label="Beds free" value={beds} onChange={setBeds} />
        <Counter label="ICU free" value={icu} onChange={setIcu} />
        <Counter label="Ventilators free" value={vents} onChange={setVents} />
      </div>

      <div className="quick">
        <button type="button" onClick={() => setIcu(0)}>Mark ICU full</button>
        <button type="button" onClick={() => { setBeds(0); setIcu(0); setVents(0) }}>Mark all full</button>
      </div>

      <div className="checks">
        <label><input type="checkbox" checked={oxygen} onChange={(e) => setOxygen(e.target.checked)} /> Oxygen available</label>
        <label><input type="checkbox" checked={ct} onChange={(e) => setCt(e.target.checked)} /> CT scan available</label>
        <label><input type="checkbox" checked={trauma} onChange={(e) => setTrauma(e.target.checked)} /> Trauma centre</label>
      </div>

      <h3>Blood groups in stock</h3>
      <Chips options={bloodOptions} selected={blood} onToggle={(v) => toggle(blood, setBlood, v)} />

      <h3>Specialties on duty</h3>
      <Chips options={specOptions} selected={specs} onToggle={(v) => toggle(specs, setSpecs, v)} />

      <div className="save-row">
        <button className="primary" onClick={save} disabled={saving || !dirty}>
          {saving ? 'Saving...' : dirty ? 'Save changes' : 'All saved'}
        </button>
        {dirty && <span className="muted">You have unsaved changes</span>}
      </div>
      {msg && <p className={isError ? 'error' : 'ok'}>{msg}</p>}
    </div>
  )
}
